
let calculation=localStorage.getItem('calculation') || '';
    function updatecalculator(value){
    calculation+= value ;
    console.log(calculation);
    document.querySelector('.cal').innerHTML=calculation;
    localStorage.setItem('calculation',calculation);
  }
  function savecalculation(){
    localStorage.setItem('calculation',JSON.stringify(calculation));
    
}
  
    

