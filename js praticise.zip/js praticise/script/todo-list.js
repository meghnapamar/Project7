let myArray=[{
  name:'make dinner',
  dueDate:'20-12-2023' }];



renderTodo();

function renderTodo(){
  let result='';

  for(let i=0;i<myArray.length;i++){
    let todoObject=myArray[i];
    const { name , dueDate }=todoObject;
  
    
    let todoHtml=`
    <div>
       ${name}
    </div>
    <div>  
      ${dueDate}
    </div>
      <button 
      onclick="
      myArray.splice(${i}, 1);
      renderTodo();
      
      " class="js-delete" 
      >Delete</button>
      
    </div>
    `;
    result+=todoHtml;
  }
  //console.log(result);
  document.querySelector('.js-todo-list').innerHTML=result;
  }

function myfun(){
  const inputElement=document.querySelector('.js-todo-name');
  const name=inputElement.value;
  const inputDuedate=document.querySelector('.js-dueDate');
  const dueDate=inputDuedate.value;

  myArray.push({name , dueDate});
  
 // console.log(myArray);

  inputElement.value='';
  renderTodo();



}