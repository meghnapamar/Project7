function myfunction(){
  let changeColor=document.querySelector('.js-btn-1');
  changeColor.classList.toggle('game-btn')
}
function mymusic(){
  let changeColor=document.querySelector('.js-btn-2');
  changeColor.classList.toggle('music-btn')
}
function mytech(){
  let changeColor=document.querySelector('.js-btn-3');
  changeColor.classList.toggle('tech-btn')

}


//game-button2

function myfun(){
  let changeColor=document.querySelector('.js-button');
  if (changeColor.innerText==='Game'){
    changeColor.classList.add('js-game');
  }else {
    changeColor.classList.remove('js-game');
  }
}
function myfunc(){
  let changeColor=document.querySelector('.js-button');

  if(changeColor.innerText==='Music'){
    changeColor.classList.add('js-music');
  }else {changeColor.classList.remove('js-music');
}
}
function myfunct(){
  let changeColor=document.querySelector('.js-button');

if(changeColor.innerText==='Music'){
  changeColor.classList.add('js-btn');
}else {changeColor.classList.remove('js-btn');
}


}